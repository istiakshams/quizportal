-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2024 at 06:16 AM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

DROP TABLE IF EXISTS `advertisements`;
CREATE TABLE IF NOT EXISTS `advertisements` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`id`, `title`, `content`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Box Ad 300X250', '<a href=\"\"><img src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRI6W5LgxEZluKjAualu_UBTrK0UXZXL-iInw&s\"></a>', 1, NULL, '2024-12-06 01:51:42'),
(2, 'Box Ad 336X280', 'adsf', 1, '2024-12-05 09:27:43', '2024-12-06 00:55:27'),
(3, 'Banner Ad 728X90', 'gfjfgj', 1, '2024-12-05 09:29:00', '2024-12-06 00:55:09'),
(18, 'asfsd', 'fdfas', 1, '2024-12-06 01:38:09', '2024-12-06 01:38:09'),
(19, 'asfasd', 'adsf', 1, '2024-12-06 01:38:12', '2024-12-06 01:38:12');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `short_description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `featured_image` int DEFAULT NULL,
  `is_featured` tinyint NOT NULL DEFAULT '0',
  `author_id` bigint NOT NULL DEFAULT '1',
  `status` enum('draft','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `meta_title` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_img` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `slug`, `description`, `short_description`, `featured_image`, `is_featured`, `author_id`, `status`, `meta_title`, `meta_description`, `meta_img`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'In hac habitasse platea dictumst', 'in-hac-habitasse-platea-dictumst', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo, eu imperdiet turpis risus in nibh. In a varius velit. Aenean ornare in nisi eu fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi ut tellus accumsan, molestie lorem vitae, congue enim. Cras ultrices posuere arcu ac pretium. Aliquam id magna id sem placerat blandit.</p><p>Aliquam gravida pharetra imperdiet. Proin sollicitudin luctus lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis nisi, lobortis quis urna vel, cursus interdum elit. Aenean vehicula mattis sapien, at porttitor purus ultricies at. Sed purus tortor, sodales vitae suscipit sed, gravida at diam. Morbi et mi nec magna aliquam pretium ut quis turpis. Nam eget vulputate quam. Etiam aliquet, urna in vehicula dictum, massa tellus placerat diam, in gravida diam nibh eget velit.</p><p>Etiam eu egestas orci. Duis a ante a ipsum vestibulum pulvinar. Praesent maximus elementum tincidunt. Donec quis lacus vel leo pharetra scelerisque vel et tortor. Fusce laoreet maximus odio non facilisis. Morbi porta vestibulum risus. Morbi eget feugiat massa, a rhoncus felis. Fusce turpis neque, viverra nec enim quis, tristique mollis neque. Nulla pharetra, ipsum non vehicula pellentesque, nisi nisl interdum ligula, quis tempus enim lorem at metus. Morbi ante est, vulputate vitae bibendum ut, blandit eu quam. Duis sit amet sollicitudin ligula, vitae laoreet elit.</p>', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo.', 75, 0, 1, 'published', 'First Blog Meta Title', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', NULL, '2024-11-06 08:39:35', '2024-12-08 07:50:41', NULL),
(4, 'Cras placerat quam quis risus cursus laoreet', 'cras-placerat-quam-quis-risus-cursus-laoreet', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo, eu imperdiet turpis risus in nibh. In a varius velit. Aenean ornare in nisi eu fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi ut tellus accumsan, molestie lorem vitae, congue enim. Cras ultrices posuere arcu ac pretium. Aliquam id magna id sem placerat blandit.</p><p>Aliquam gravida pharetra imperdiet. Proin sollicitudin luctus lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis nisi, lobortis quis urna vel, cursus interdum elit. Aenean vehicula mattis sapien, at porttitor purus ultricies at. Sed purus tortor, sodales vitae suscipit sed, gravida at diam. Morbi et mi nec magna aliquam pretium ut quis turpis. Nam eget vulputate quam. Etiam aliquet, urna in vehicula dictum, massa tellus placerat diam, in gravida diam nibh eget velit.</p><p>Etiam eu egestas orci. Duis a ante a ipsum vestibulum pulvinar. Praesent maximus elementum tincidunt. Donec quis lacus vel leo pharetra scelerisque vel et tortor. Fusce laoreet maximus odio non facilisis. Morbi porta vestibulum risus. Morbi eget feugiat massa, a rhoncus felis. Fusce turpis neque, viverra nec enim quis, tristique mollis neque. Nulla pharetra, ipsum non vehicula pellentesque, nisi nisl interdum ligula, quis tempus enim lorem at metus. Morbi ante est, vulputate vitae bibendum ut, blandit eu quam. Duis sit amet sollicitudin ligula, vitae laoreet elit.</p>', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo.', 77, 1, 1, 'published', NULL, NULL, NULL, '2024-11-06 08:58:46', '2024-12-08 07:57:40', NULL),
(5, 'Third Blog', 'first-blog-3', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo, eu imperdiet turpis risus in nibh. In a varius velit. Aenean ornare in nisi eu fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi ut tellus accumsan, molestie lorem vitae, congue enim. Cras ultrices posuere arcu ac pretium. Aliquam id magna id sem placerat blandit.</p><p>Aliquam gravida pharetra imperdiet. Proin sollicitudin luctus lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis nisi, lobortis quis urna vel, cursus interdum elit. Aenean vehicula mattis sapien, at porttitor purus ultricies at. Sed purus tortor, sodales vitae suscipit sed, gravida at diam. Morbi et mi nec magna aliquam pretium ut quis turpis. Nam eget vulputate quam. Etiam aliquet, urna in vehicula dictum, massa tellus placerat diam, in gravida diam nibh eget velit.</p><p>Etiam eu egestas orci. Duis a ante a ipsum vestibulum pulvinar. Praesent maximus elementum tincidunt. Donec quis lacus vel leo pharetra scelerisque vel et tortor. Fusce laoreet maximus odio non facilisis. Morbi porta vestibulum risus. Morbi eget feugiat massa, a rhoncus felis. Fusce turpis neque, viverra nec enim quis, tristique mollis neque. Nulla pharetra, ipsum non vehicula pellentesque, nisi nisl interdum ligula, quis tempus enim lorem at metus. Morbi ante est, vulputate vitae bibendum ut, blandit eu quam. Duis sit amet sollicitudin ligula, vitae laoreet elit.</p>', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo.', 78, 1, 1, 'published', 'First Blog', 'First Blog', NULL, '2024-11-06 09:09:38', '2024-12-08 07:58:17', NULL),
(7, 'Foruth Blog', 'first-blog-4', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo, eu imperdiet turpis risus in nibh. In a varius velit. Aenean ornare in nisi eu fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi ut tellus accumsan, molestie lorem vitae, congue enim. Cras ultrices posuere arcu ac pretium. Aliquam id magna id sem placerat blandit.</p><p>Aliquam gravida pharetra imperdiet. Proin sollicitudin luctus lobortis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce felis nisi, lobortis quis urna vel, cursus interdum elit. Aenean vehicula mattis sapien, at porttitor purus ultricies at. Sed purus tortor, sodales vitae suscipit sed, gravida at diam. Morbi et mi nec magna aliquam pretium ut quis turpis. Nam eget vulputate quam. Etiam aliquet, urna in vehicula dictum, massa tellus placerat diam, in gravida diam nibh eget velit.</p><p>Etiam eu egestas orci. Duis a ante a ipsum vestibulum pulvinar. Praesent maximus elementum tincidunt. Donec quis lacus vel leo pharetra scelerisque vel et tortor. Fusce laoreet maximus odio non facilisis. Morbi porta vestibulum risus. Morbi eget feugiat massa, a rhoncus felis. Fusce turpis neque, viverra nec enim quis, tristique mollis neque. Nulla pharetra, ipsum non vehicula pellentesque, nisi nisl interdum ligula, quis tempus enim lorem at metus. Morbi ante est, vulputate vitae bibendum ut, blandit eu quam. Duis sit amet sollicitudin ligula, vitae laoreet elit.</p>', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas convallis, ligula fringilla feugiat ullamcorper, mauris lorem eleifend leo.', 79, 1, 1, 'published', NULL, NULL, NULL, '2024-11-06 09:57:36', '2024-12-08 07:58:28', NULL),
(8, 'Etiam sit amet nisi mollis pharetra ex sed', 'etiam-sit-amet-nisi-mollis-pharetra-ex-sed', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">In hac habitasse platea dictumst. Maecenas felis velit, eleifend quis sapien in, consectetur efficitur lectus. Cras placerat quam quis risus cursus laoreet. Pellentesque hendrerit ultricies commodo. Nam tristique elit fermentum ipsum sollicitudin, vitae placerat nibh sodales. Duis faucibus est lacus, vel ornare ligula finibus sed. Vivamus varius ex massa, in placerat velit ultricies ac.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Vivamus pharetra varius libero a gravida. Etiam est neque, aliquet vel augue sed, malesuada imperdiet magna. Nam pretium odio quis tincidunt egestas. In efficitur orci vel venenatis feugiat. Curabitur vitae tincidunt ante, vitae posuere enim. Suspendisse maximus nulla consectetur ullamcorper posuere. Vestibulum sed volutpat justo. Donec ultricies, risus vitae consequat gravida, ligula nibh blandit sem, eu suscipit dui ipsum id quam. In nec semper urna.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Sed vulputate ac nulla vel hendrerit. Suspendisse malesuada nulla lectus, sit amet tincidunt erat rhoncus id. Sed consequat risus at dolor molestie semper. Nunc sollicitudin diam id ipsum consectetur vulputate. Donec at erat purus. Aenean congue bibendum tellus, at volutpat nunc feugiat ac. Ut metus dui, luctus nec ex nec, iaculis porta quam. Ut tortor dui, feugiat in risus eu, porttitor iaculis lacus. Suspendisse pulvinar suscipit metus, ut rhoncus turpis aliquam in. Pellentesque vel finibus ante. Phasellus condimentum nisi dui, nec gravida arcu sollicitudin ut. Curabitur lacinia commodo consectetur.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Integer at accumsan enim. Vestibulum at fermentum ex. Etiam sit amet nisi mollis, pharetra ex sed, luctus ipsum. Quisque condimentum interdum aliquet. Curabitur sed urna et mauris lobortis euismod. Sed ac egestas dui. Etiam hendrerit imperdiet posuere. Morbi aliquet elit metus, nec tincidunt leo pellentesque quis. Nunc auctor suscipit urna, eu convallis justo eleifend a. Aenean ornare, risus viverra congue congue, nunc ipsum elementum justo, quis finibus felis elit vitae libero. Etiam nibh nunc, tincidunt non mauris sit amet, rhoncus venenatis magna. Morbi finibus consectetur libero vel eleifend. Nunc iaculis luctus ante eleifend maximus. Integer dapibus tristique lacinia.</p>', NULL, 80, 0, 1, 'published', NULL, NULL, NULL, '2024-11-15 12:12:57', '2024-12-08 07:59:28', NULL),
(9, 'Nam pretium odio quis tincidunt egestas', 'nam-pretium-odio-quis-tincidunt-egestas', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel metus diam. Nulla facilisi. Integer dapibus mattis felis, sit amet commodo risus laoreet ut. Nulla facilisi. Vestibulum efficitur auctor massa. Quisque imperdiet lobortis ligula, feugiat porta justo accumsan eu. Vestibulum condimentum, nisi eleifend commodo ornare, lectus nunc feugiat erat, ut tincidunt massa mauris non nibh. Suspendisse gravida ex vulputate ipsum euismod, eget vulputate dolor maximus.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">In hac habitasse platea dictumst. Maecenas felis velit, eleifend quis sapien in, consectetur efficitur lectus. Cras placerat quam quis risus cursus laoreet. Pellentesque hendrerit ultricies commodo. Nam tristique elit fermentum ipsum sollicitudin, vitae placerat nibh sodales. Duis faucibus est lacus, vel ornare ligula finibus sed. Vivamus varius ex massa, in placerat velit ultricies ac.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Vivamus pharetra varius libero a gravida. Etiam est neque, aliquet vel augue sed, malesuada imperdiet magna. Nam pretium odio quis tincidunt egestas. In efficitur orci vel venenatis feugiat. Curabitur vitae tincidunt ante, vitae posuere enim. Suspendisse maximus nulla consectetur ullamcorper posuere. Vestibulum sed volutpat justo. Donec ultricies, risus vitae consequat gravida, ligula nibh blandit sem, eu suscipit dui ipsum id quam. In nec semper urna.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Sed vulputate ac nulla vel hendrerit. Suspendisse malesuada nulla lectus, sit amet tincidunt erat rhoncus id. Sed consequat risus at dolor molestie semper. Nunc sollicitudin diam id ipsum consectetur vulputate. Donec at erat purus. Aenean congue bibendum tellus, at volutpat nunc feugiat ac. Ut metus dui, luctus nec ex nec, iaculis porta quam. Ut tortor dui, feugiat in risus eu, porttitor iaculis lacus. Suspendisse pulvinar suscipit metus, ut rhoncus turpis aliquam in. Pellentesque vel finibus ante. Phasellus condimentum nisi dui, nec gravida arcu sollicitudin ut. Curabitur lacinia commodo consectetur.</p>', NULL, 81, 0, 1, 'published', NULL, NULL, NULL, '2024-12-08 07:51:32', '2024-12-08 07:59:56', NULL),
(10, 'Vivamus pharetra varius libero a gravida', 'vivamus-pharetra-varius-libero-a-gravida', '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel metus diam. Nulla facilisi. Integer dapibus mattis felis, sit amet commodo risus laoreet ut. Nulla facilisi. Vestibulum efficitur auctor massa. Quisque imperdiet lobortis ligula, feugiat porta justo accumsan eu. Vestibulum condimentum, nisi eleifend commodo ornare, lectus nunc feugiat erat, ut tincidunt massa mauris non nibh. Suspendisse gravida ex vulputate ipsum euismod, eget vulputate dolor maximus.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">In hac habitasse platea dictumst. Maecenas felis velit, eleifend quis sapien in, consectetur efficitur lectus. Cras placerat quam quis risus cursus laoreet. Pellentesque hendrerit ultricies commodo. Nam tristique elit fermentum ipsum sollicitudin, vitae placerat nibh sodales. Duis faucibus est lacus, vel ornare ligula finibus sed. Vivamus varius ex massa, in placerat velit ultricies ac.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Vivamus pharetra varius libero a gravida. Etiam est neque, aliquet vel augue sed, malesuada imperdiet magna. Nam pretium odio quis tincidunt egestas. In efficitur orci vel venenatis feugiat. Curabitur vitae tincidunt ante, vitae posuere enim. Suspendisse maximus nulla consectetur ullamcorper posuere. Vestibulum sed volutpat justo. Donec ultricies, risus vitae consequat gravida, ligula nibh blandit sem, eu suscipit dui ipsum id quam. In nec semper urna.</p><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">Sed vulputate ac nulla vel hendrerit. Suspendisse malesuada nulla lectus, sit amet tincidunt erat rhoncus id. Sed consequat risus at dolor molestie semper. Nunc sollicitudin diam id ipsum consectetur vulputate. Donec at erat purus. Aenean congue bibendum tellus, at volutpat nunc feugiat ac. Ut metus dui, luctus nec ex nec, iaculis porta quam. Ut tortor dui, feugiat in risus eu, porttitor iaculis lacus. Suspendisse pulvinar suscipit metus, ut rhoncus turpis aliquam in. Pellentesque vel finibus ante. Phasellus condimentum nisi dui, nec gravida arcu sollicitudin ut. Curabitur lacinia commodo consectetur.</p>', NULL, 76, 0, 1, 'published', NULL, NULL, NULL, '2024-12-08 07:56:56', '2024-12-08 07:56:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_blog_category`
--

DROP TABLE IF EXISTS `blog_blog_category`;
CREATE TABLE IF NOT EXISTS `blog_blog_category` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `blog_id` bigint UNSIGNED NOT NULL,
  `blog_category_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_blog_category_blog_id_foreign` (`blog_id`),
  KEY `blog_blog_category_blog_category_id_foreign` (`blog_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_blog_category`
--

INSERT INTO `blog_blog_category` (`id`, `blog_id`, `blog_category_id`, `created_at`, `updated_at`) VALUES
(8, 2, 1, NULL, NULL),
(3, 4, 2, NULL, NULL),
(4, 5, 1, NULL, NULL),
(9, 8, 2, NULL, NULL),
(6, 7, 1, NULL, NULL),
(7, 7, 2, NULL, NULL),
(10, 9, 1, NULL, NULL),
(11, 10, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE IF NOT EXISTS `blog_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_img` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `slug`, `meta_title`, `meta_description`, `meta_img`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, 'Travel', 'travel', 'Travel Meta Title', 'Travel Meta Description', NULL, '2024-11-06 08:24:09', '2024-11-15 07:20:41', NULL),
(4, 'Technology', 'technology', NULL, NULL, NULL, '2024-12-08 08:19:25', '2024-12-08 08:19:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE IF NOT EXISTS `favorites` (
  `user_id` int UNSIGNED NOT NULL,
  `favoriteable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `favoriteable_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`favoriteable_id`,`favoriteable_type`),
  KEY `favorites_favoriteable_type_favoriteable_id_index` (`favoriteable_type`,`favoriteable_id`),
  KEY `favorites_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `general_setup_localizations`
--

DROP TABLE IF EXISTS `general_setup_localizations`;
CREATE TABLE IF NOT EXISTS `general_setup_localizations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `system_setting_id` int DEFAULT NULL,
  `entity` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `lang_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `flag` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_rtl` tinyint NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `is_active_for_templates` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `flag`, `code`, `is_rtl`, `is_active`, `is_active_for_templates`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'English', 'us', 'en', 0, 1, 1, '2024-11-17 09:43:02', '2024-11-17 23:23:13', NULL),
(2, 'Bangla', 'bd', 'bn', 0, 0, 1, '2024-11-17 10:28:58', '2024-11-18 10:16:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `localizations`
--

DROP TABLE IF EXISTS `localizations`;
CREATE TABLE IF NOT EXISTS `localizations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `lang_key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `t_key` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `t_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `localizations`
--

INSERT INTO `localizations` (`id`, `lang_key`, `t_key`, `t_value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'en', 'delete_confirmation', 'Delete Confirmation', '2024-11-10 03:36:31', '2024-11-10 03:36:31', NULL),
(2, 'en', 'are_you_sure_to_delete_this', 'Are you sure to delete this?', '2024-11-10 03:36:31', '2024-11-10 03:36:31', NULL),
(3, 'en', 'all_data_related_to_this_may_get_deleted', 'All data related to this may get deleted.', '2024-11-10 03:36:31', '2024-11-10 03:36:31', NULL),
(4, 'en', 'proceed', 'Proceed', '2024-11-10 03:36:31', '2024-11-10 03:36:31', NULL),
(5, 'en', 'cancel', 'Cancel', '2024-11-10 03:36:31', '2024-11-10 03:36:31', NULL),
(6, 'en', 'are_you_sure_to_delete_all_data', 'Are you sure to delete all data?', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(7, 'en', 'hidden_confirmation', 'Hidden Confirmation', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(8, 'en', 'are_you_sure_to_hide_this', 'Are you sure to hide this?', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(9, 'en', 'approve_confirmation', 'Approve Confirmation', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(10, 'en', 'are_you_sure_to_approve_this', 'Are you sure to Approve this?', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(11, 'en', 'reject_confirmation', 'Reject Confirmation', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(12, 'en', 'are_you_sure_to_reject_this', 'Are you sure to Reject this?', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(13, 'en', 'resubmit_confirmation', 'Re-Submit Confirmation', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(14, 'en', 'are_you_sure_to_resubmit_this', 'Are you sure to Re-Submit this?', '2024-11-10 03:36:32', '2024-11-10 03:36:32', NULL),
(15, 'en', 'sl', 'S/L', '2024-11-17 08:52:40', '2024-11-17 08:52:40', NULL),
(16, 'en', 'name', 'Name', '2024-11-17 08:52:40', '2024-11-17 08:52:40', NULL),
(17, 'en', 'iso_6391_code', 'ISO 639-1 Code', '2024-11-17 08:52:40', '2024-11-17 08:52:40', NULL),
(18, 'en', 'multilangual_support', 'MultiLangual Support', '2024-11-17 08:52:40', '2024-11-17 08:52:40', NULL),
(19, 'en', 'show_in_templates', 'Show In Templates', '2024-11-17 08:52:40', '2024-11-17 08:52:40', NULL),
(20, 'en', 'action', 'Action', '2024-11-17 08:52:40', '2024-11-17 08:52:40', NULL),
(21, 'en', 'add_new_language', 'Add New Language', '2024-11-17 09:26:55', '2024-11-17 09:26:55', NULL),
(22, 'en', 'language_name', 'Language Name', '2024-11-17 09:26:55', '2024-11-17 09:26:55', NULL),
(23, 'en', 'type_language_name', 'Type language name', '2024-11-17 09:26:55', '2024-11-17 09:26:55', NULL),
(24, 'en', 'enbn', 'en/bn', '2024-11-17 09:26:55', '2024-11-17 09:26:55', NULL),
(25, 'en', 'flag', 'Flag', '2024-11-17 09:26:55', '2024-11-17 09:26:55', NULL),
(26, 'en', 'is_rtl_', 'Is RTL ?', '2024-11-17 09:29:33', '2024-11-17 09:29:33', NULL),
(27, 'en', 'no', 'No', '2024-11-17 09:29:33', '2024-11-17 09:29:33', NULL),
(28, 'en', 'yes', 'Yes', '2024-11-17 09:29:33', '2024-11-17 09:29:33', NULL),
(29, 'en', 'save_language', 'Save Language', '2024-11-17 09:29:33', '2024-11-17 09:29:33', NULL),
(30, 'en', 'set_default_language', 'Set Default Language', '2024-11-17 10:33:10', '2024-11-17 10:33:10', NULL),
(31, 'en', 'default_language', 'Default Language', '2024-11-17 10:33:10', '2024-11-17 10:33:10', NULL),
(32, 'en', 'set_language', 'Set Language', '2024-11-17 10:43:53', '2024-11-17 10:43:53', NULL),
(33, 'en', 'status_updated_successfully', 'Status updated successfully', '2024-11-17 11:26:12', '2024-11-17 11:26:12', NULL),
(34, 'en', 'minimum_1_language_need_to_be_enabled', 'Minimum 1 language need to be enabled', '2024-11-17 11:26:20', '2024-11-17 11:26:20', NULL),
(35, 'en', 'update_language', 'Update Language', '2024-11-18 09:49:26', '2024-11-18 09:49:26', NULL),
(36, 'en', 'lang_key', 'Lang Key', '2024-11-21 01:29:31', '2024-11-21 01:29:31', NULL),
(37, 'en', 'localizations', 'Localizations', '2024-11-21 01:29:31', '2024-11-21 01:29:31', NULL),
(38, 'en', 'type_localization_here', 'Type localization here', '2024-11-21 01:30:48', '2024-11-21 01:30:48', NULL),
(39, 'bn', 'delete_confirmation', 'De', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `media_managers`
--

DROP TABLE IF EXISTS `media_managers`;
CREATE TABLE IF NOT EXISTS `media_managers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `media_file` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `media_size` int DEFAULT NULL,
  `media_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'video / image / pdf / ...',
  `media_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `media_extension` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media_managers`
--

INSERT INTO `media_managers` (`id`, `user_id`, `media_file`, `media_size`, `media_type`, `media_name`, `media_extension`, `created_at`, `updated_at`, `deleted_at`) VALUES
(58, 1, 'media/1731234613_107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 954980, 'image', '107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 'jpg', '2024-11-10 04:30:13', '2024-11-10 04:30:13', NULL),
(59, 1, 'media/1731234696_107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 954980, 'image', '107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 'jpg', '2024-11-10 04:31:36', '2024-11-10 04:31:36', NULL),
(55, 1, 'media/1731233657_107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 954980, 'image', '107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 'jpg', '2024-11-10 04:14:17', '2024-11-10 04:14:17', NULL),
(56, 1, 'media/1731233677_81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 448107, 'image', '81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 'jpg', '2024-11-10 04:14:37', '2024-11-10 04:14:37', NULL),
(57, 1, 'media/1731233751_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 04:15:51', '2024-11-10 04:15:51', NULL),
(14, 1, 'media/1.jpg', 448107, 'image', '1', 'jpg', '2024-11-09 09:04:31', '2024-11-09 09:04:31', NULL),
(13, 1, 'media/2.jpg', 726708, 'image', '2', 'jpg', '2024-11-09 09:04:21', '2024-11-09 09:04:21', NULL),
(53, 1, 'media/1731233631_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 04:13:51', '2024-11-10 04:13:51', NULL),
(12, 1, 'media/3.jpg', 188122, 'image', '3', 'webp', '2024-11-09 09:02:09', '2024-11-09 09:02:09', NULL),
(54, 1, 'media/1731233647_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 04:14:07', '2024-11-10 04:14:07', NULL),
(10, 1, 'media/J4OwPHjUSIKhbkjDW7ezlXBeP2PaMbZeLproTi9Z.png', 585959, 'image', 'a modern looking male avatar that can be used in forums and other profiles.png', 'png', '2024-11-07 10:27:04', '2024-11-07 10:27:04', NULL),
(49, 1, 'media/1731224854_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 01:47:34', '2024-11-10 01:47:34', NULL),
(48, 1, 'media/1731224706_car.jpg', 1239745, 'image', 'car.jpg', 'jpg', '2024-11-10 01:45:06', '2024-11-10 01:45:06', NULL),
(47, 1, 'media/1731224588_car.jpg', 1239745, 'image', 'car.jpg', 'jpg', '2024-11-10 01:43:08', '2024-11-10 01:43:08', NULL),
(60, 1, 'media/1731234889_car.jpg', 1239745, 'image', 'car.jpg', 'jpg', '2024-11-10 04:34:49', '2024-11-10 04:34:49', NULL),
(61, 1, 'media/1731234929_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 04:35:29', '2024-11-10 04:35:29', NULL),
(62, 1, 'media/1731234993_81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 448107, 'image', '81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 'jpg', '2024-11-10 04:36:33', '2024-11-10 04:36:33', NULL),
(63, 1, 'media/1731235034_81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 448107, 'image', '81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 'jpg', '2024-11-10 04:37:14', '2024-11-10 04:37:14', NULL),
(64, 1, 'media/1731235228_81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 448107, 'image', '81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 'jpg', '2024-11-10 04:40:28', '2024-11-10 04:40:28', NULL),
(65, 1, 'media/1731235294_107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 954980, 'image', '107feaa1db63e86b9e1f14b089ded7ab_high.jpg', 'jpg', '2024-11-10 04:41:34', '2024-11-10 04:41:34', NULL),
(66, 1, 'media/1731235357_81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 448107, 'image', '81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 'jpg', '2024-11-10 04:42:37', '2024-11-10 04:42:37', NULL),
(67, 1, 'media/1731235380_81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 448107, 'image', '81adee1d0e93f2e274ad19a5d94d86f9_high.jpg', 'jpg', '2024-11-10 04:43:00', '2024-11-10 04:43:00', NULL),
(68, 1, 'media/1731235393_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 04:43:13', '2024-11-10 04:43:13', NULL),
(69, 1, 'media/1731235514_car.jpg', 1239745, 'image', 'car.jpg', 'jpg', '2024-11-10 04:45:14', '2024-11-10 04:45:14', NULL),
(70, 1, 'media/1731249952_a3cc909fff6ba5206c531c838ce23632_high.jpg', 995216, 'image', 'a3cc909fff6ba5206c531c838ce23632_high.jpg', 'jpg', '2024-11-10 08:45:52', '2024-11-10 08:45:52', NULL),
(71, 1, 'media/1731667827_logo-1-light.png', 5169, 'image', 'logo-1-light.png', 'png', '2024-11-15 04:50:27', '2024-11-15 04:50:27', NULL),
(72, 1, 'media/1731668763_logo-1-dark.png', 5071, 'image', 'logo-1-dark.png', 'png', '2024-11-15 05:06:03', '2024-11-15 05:06:03', NULL),
(73, 1, 'media/1731668779_favicon.png', 9968, 'image', 'favicon.png', 'png', '2024-11-15 05:06:19', '2024-11-15 05:06:19', NULL),
(75, 1, 'media/1731678185_pexels-joshkjack-135018.jpg', 177642, 'image', 'pexels-joshkjack-135018.jpg', 'jpg', '2024-11-15 07:43:05', '2024-11-15 07:43:05', NULL),
(76, 1, 'media/1733666208_pexels-kyleroxas-2138922.jpg', 136218, 'image', 'pexels-kyleroxas-2138922.jpg', 'jpg', '2024-12-08 07:56:48', '2024-12-08 07:56:48', NULL),
(77, 1, 'media/1733666240_pexels-woro2x-2275992.jpg', 114556, 'image', 'pexels-woro2x-2275992.jpg', 'jpg', '2024-12-08 07:57:20', '2024-12-08 07:57:20', NULL),
(78, 1, 'media/1733666291_pexels-blitzboy-1144176.jpg', 83432, 'image', 'pexels-blitzboy-1144176.jpg', 'jpg', '2024-12-08 07:58:11', '2024-12-08 07:58:11', NULL),
(79, 1, 'media/1733666304_pexels-lum3n-44775-167684.jpg', 183867, 'image', 'pexels-lum3n-44775-167684.jpg', 'jpg', '2024-12-08 07:58:24', '2024-12-08 07:58:24', NULL),
(80, 1, 'media/1733666336_pexels-nout-gons-80280-248159.jpg', 178808, 'image', 'pexels-nout-gons-80280-248159.jpg', 'jpg', '2024-12-08 07:58:56', '2024-12-08 07:58:56', NULL),
(81, 1, 'media/1733666389_pexels-postiglioni-1537979.jpg', 201989, 'image', 'pexels-postiglioni-1537979.jpg', 'jpg', '2024-12-08 07:59:49', '2024-12-08 07:59:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2020_05_13_011108_create_permission_tables', 2),
(38, '2024_12_10_052826_create_quiz_table', 14),
(39, '2024_12_10_063513_create_quiz_categories_table', 15),
(9, '2020_05_13_215433_create_favorites_table', 2),
(61, '2024_12_12_080645_create_poll_choices_table', 18),
(60, '2024_12_12_080637_create_polls_table', 18),
(54, '2024_12_12_080645_create_pollchoices_table', 17),
(20, '2024_11_03_055500_create_blogs_table', 5),
(21, '2024_11_03_055542_create_blog_categories_table', 5),
(40, '2024_12_10_135334_create_questions_table', 16),
(23, '2024_11_03_110956_create_pages_table', 6),
(24, '2024_11_03_135915_create_system_settings_table', 7),
(27, '2024_11_06_104417_create_theme_settings_table', 8),
(29, '2024_11_06_144911_create_blog_blog_category_table', 9),
(30, '2024_11_06_144912_create_media_managers_table', 10),
(31, '2024_11_06_144913_create_localizations_table', 11),
(32, '2024_11_06_144914_create_general_setup_localizations_table', 11),
(33, '2024_11_06_144915_create_languages_table', 12),
(36, '2024_12_05_070950_create_advertisements_table', 13),
(62, '2024_12_12_080652_create_votes_table', 18);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE IF NOT EXISTS `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE IF NOT EXISTS `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(5, 'App\\Models\\User', 17);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `featured_image` int DEFAULT NULL,
  `status` enum('draft','published') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `meta_title` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_img` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `content`, `featured_image`, `status`, `meta_title`, `meta_description`, `meta_img`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Home Page', 'home-page', '<p>Home Page Content</p>', 75, 'published', NULL, NULL, NULL, '2024-11-03 05:48:13', '2024-11-15 12:08:37', NULL),
(2, 'Contact Us', 'contact-us', '<h2 class=\"\">Get In Touch</h2><p><b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur tincidunt ac purus eget scelerisque.</b></p><p>Duis mollis pretium egestas. Proin congue purus a ex ullamcorper, at lobortis ante rhoncus. Etiam vel nunc elit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>', NULL, 'published', 'Contact Us', 'Qubix Portal Contact Us', NULL, '2024-11-03 06:03:52', '2024-11-17 01:06:48', NULL),
(3, 'About Us', 'about-us', '<p>About Us</p>', NULL, 'published', 'About Us', 'Qubix Portal About Us', NULL, '2024-11-03 06:04:02', '2024-11-15 07:00:02', NULL),
(4, 'Privacy Policy', 'privacy-policy', '<p>Privacy Policy</p>', NULL, 'published', 'Privacy Policy', 'Qubix Portal Privacy Policy', NULL, '2024-11-03 06:04:12', '2024-11-15 07:00:16', NULL),
(5, 'Terms and Conditions', 'terms-and-conditions', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer in velit consequat, sagittis ante sed, eleifend risus. Quisque rutrum, justo vel rutrum scelerisque, elit augue maximus massa, vitae eleifend est augue eget orci. Duis a eros tempus nisl ultricies vulputate non id sem. Donec et lorem suscipit, volutpat nisi ut, dapibus tortor. Sed iaculis maximus ante, a sollicitudin augue pharetra vel. Fusce eu nisi vehicula, pellentesque neque in, finibus purus. Vivamus rutrum rhoncus lorem, in ultricies nibh bibendum lacinia. In hac habitasse platea dictumst. Suspendisse lacus est, hendrerit at metus sed, maximus viverra nisl.</p><p>Nulla scelerisque volutpat lacinia. Curabitur fermentum ex nec elit elementum ullamcorper. Proin dignissim tellus nibh, sit amet rutrum purus mollis et. Morbi a enim elit. Mauris a vulputate libero. Phasellus facilisis sapien nec lacus maximus, non tincidunt odio convallis. Ut ut pulvinar tortor. Integer sed dictum arcu. Vestibulum ut sodales erat.</p><p>Vestibulum sed purus consectetur, dignissim tellus eget, rhoncus enim. Mauris non sapien diam. Duis rhoncus, mi et varius facilisis, dui dolor sodales turpis, sit amet eleifend leo lectus nec massa. Pellentesque dictum purus ac urna maximus ultrices. Praesent tempus mollis mollis. Quisque commodo auctor dictum. Suspendisse blandit sem ut venenatis semper. Donec vehicula mi consequat nibh sagittis tempus. Curabitur vel efficitur sapien, nec fringilla dui. Maecenas ultricies eros at tortor tristique vulputate. Curabitur sed velit tempor, posuere lorem ut, vehicula dui. Mauris ullamcorper turpis turpis, id pharetra nisl efficitur ut. Nullam id ex ut nunc porta feugiat. Quisque tristique venenatis sapien. In gravida neque sit amet blandit bibendum. Integer ullamcorper lobortis augue eget imperdiet.</p><p>Etiam vitae fermentum felis. Nunc lacinia porttitor enim eu lacinia. Aliquam diam neque, vehicula quis sollicitudin et, molestie ac orci. Cras ut velit pellentesque, volutpat orci sed, consectetur lorem. Sed gravida ex vel lacinia posuere. Sed mattis justo ac ultrices pellentesque. Nulla eget tellus eget nisl congue aliquet. Aenean in sodales sem. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.</p><p>Praesent porttitor, nisl ut elementum interdum, augue massa venenatis diam, nec vehicula velit quam vitae velit. Suspendisse ultrices suscipit orci, euismod sodales nulla rhoncus vitae. Mauris nulla neque, aliquet et tempor eget, sagittis sed nisl. Nullam quam ante, convallis sed consequat quis, tempus sed diam. Suspendisse luctus velit at libero egestas vestibulum. Etiam eleifend in lectus in pellentesque. Donec vulputate lorem id pharetra eleifend. Morbi maximus orci laoreet lorem ornare egestas. Quisque et ligula enim.</p>', NULL, 'published', 'Terms and Conditions Meta Title', 'Terms and Conditions Qubix Portal', NULL, '2024-11-03 06:04:21', '2024-11-15 07:05:47', NULL),
(7, 'Test 1', 'test-1', '<p>Test</p>', NULL, 'published', 'Meta Title', 'Meta Description', NULL, '2024-11-07 06:54:03', '2024-11-07 07:49:17', NULL),
(8, 'AA', 'aa', NULL, 69, 'published', NULL, NULL, NULL, '2024-11-15 12:10:19', '2024-11-15 12:11:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Browse Admin', 'web', '2024-09-18 08:48:28', '2024-09-18 08:48:28'),
(10, 'Manage Blogs', 'web', '2024-11-12 06:05:50', '2024-11-12 06:05:50'),
(3, 'Browse Frontend', 'web', '2024-09-18 08:56:17', '2024-11-12 05:57:47'),
(11, 'Add Blogs', 'web', '2024-11-12 06:06:39', '2024-11-12 06:06:39'),
(9, 'Manage Content', 'web', '2024-11-12 06:05:21', '2024-11-12 06:05:21'),
(12, 'Edit Blogs', 'web', '2024-11-12 06:06:45', '2024-11-12 06:06:45'),
(13, 'Delete Blogs', 'web', '2024-11-12 06:06:54', '2024-11-12 06:06:54'),
(14, 'Add Categories', 'web', '2024-11-12 06:07:31', '2024-11-12 06:07:31'),
(15, 'Edit Categories', 'web', '2024-11-12 06:07:41', '2024-11-12 06:07:41'),
(16, 'Delete Categories', 'web', '2024-11-12 06:08:02', '2024-11-12 06:08:02'),
(17, 'Manage Pages', 'web', '2024-11-12 06:09:18', '2024-11-12 06:09:18'),
(18, 'Add Pages', 'web', '2024-11-12 06:09:23', '2024-11-12 06:09:23'),
(19, 'Edit Pages', 'web', '2024-11-12 06:09:29', '2024-11-12 06:09:29'),
(20, 'Delete Pages', 'web', '2024-11-12 06:09:35', '2024-11-12 06:09:35'),
(21, 'Manage Media', 'web', '2024-11-12 06:09:55', '2024-11-12 06:09:55'),
(22, 'Manage Newsletters', 'web', '2024-11-12 06:11:40', '2024-11-12 06:11:40'),
(23, 'Manage Bulk Email', 'web', '2024-11-12 06:11:48', '2024-11-12 06:11:48'),
(24, 'Manage Subscribers', 'web', '2024-11-12 06:11:56', '2024-11-12 06:11:56'),
(25, 'Manage Support', 'web', '2024-11-12 06:12:41', '2024-11-12 06:12:41'),
(26, 'Manage Tickets', 'web', '2024-11-12 06:13:40', '2024-11-12 06:13:40'),
(27, 'Manage Ticket Categories', 'web', '2024-11-12 06:13:48', '2024-11-12 06:13:48'),
(28, 'Manage Subscriptions', 'web', '2024-11-12 06:14:33', '2024-11-12 06:14:33'),
(29, 'Manage Packages', 'web', '2024-11-12 06:14:41', '2024-11-12 06:40:49'),
(30, 'Manage Members', 'web', '2024-11-12 06:15:26', '2024-11-12 06:15:26'),
(31, 'Add Members', 'web', '2024-11-12 06:15:31', '2024-11-12 06:15:31'),
(32, 'Edit Members', 'web', '2024-11-12 06:15:36', '2024-11-12 06:15:36'),
(33, 'Delete Members', 'web', '2024-11-12 06:15:44', '2024-11-12 06:15:44'),
(34, 'Manage Admins', 'web', '2024-11-12 06:16:18', '2024-11-12 06:16:18'),
(35, 'Manage Roles', 'web', '2024-11-12 06:16:43', '2024-11-12 06:16:43'),
(36, 'Add Roles', 'web', '2024-11-12 06:16:47', '2024-11-12 06:16:47'),
(37, 'Edit Roles', 'web', '2024-11-12 06:16:52', '2024-11-12 06:16:52'),
(38, 'Delete Roles', 'web', '2024-11-12 06:16:58', '2024-11-12 06:16:58'),
(39, 'Manage Permissions', 'web', '2024-11-12 06:17:28', '2024-11-12 06:17:28'),
(40, 'Add Permissions', 'web', '2024-11-12 06:17:32', '2024-11-12 06:17:32'),
(41, 'Edit Permissions', 'web', '2024-11-12 06:17:38', '2024-11-12 06:17:38'),
(42, 'Delete Permissions', 'web', '2024-11-12 06:17:44', '2024-11-12 06:17:44'),
(43, 'Manage Affiliates', 'web', '2024-11-12 06:18:58', '2024-11-12 06:18:58'),
(44, 'Manage Withdraw Requests', 'web', '2024-11-12 06:19:05', '2024-11-12 06:19:05'),
(45, 'Manage Earning Histories', 'web', '2024-11-12 06:19:13', '2024-11-12 06:19:13'),
(46, 'Manage Payment Histories', 'web', '2024-11-12 06:19:20', '2024-11-12 06:19:20'),
(47, 'Manage Affiliates Settings', 'web', '2024-11-12 06:19:28', '2024-11-12 06:19:28'),
(48, 'Manage Reports', 'web', '2024-11-12 06:19:56', '2024-11-12 06:19:56'),
(49, 'Manage Subscriptions Report', 'web', '2024-11-12 06:20:10', '2024-11-12 06:20:10'),
(50, 'Manage Appearance', 'web', '2024-11-12 06:20:40', '2024-11-12 06:20:40'),
(51, 'Manage Settings', 'web', '2024-11-12 06:23:08', '2024-11-12 06:23:08'),
(52, 'Manage Utilities', 'web', '2024-11-12 06:23:28', '2024-11-12 06:23:28');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
CREATE TABLE IF NOT EXISTS `polls` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` int DEFAULT NULL,
  `maxCheck` int NOT NULL DEFAULT '0',
  `canVisitorsVote` tinyint(1) NOT NULL DEFAULT '0',
  `author_id` bigint NOT NULL DEFAULT '1',
  `status` enum('draft','published','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `meta_title` mediumtext COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `meta_img` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `polls`
--

INSERT INTO `polls` (`id`, `question`, `image`, `maxCheck`, `canVisitorsVote`, `author_id`, `status`, `meta_title`, `meta_description`, `meta_img`, `created_at`, `updated_at`) VALUES
(1, 'What is the Best Web Browser?', 78, 1, 1, 17, 'published', NULL, NULL, NULL, '2024-12-12 08:26:04', '2024-12-14 02:14:27'),
(2, 'asdfaff', NULL, 0, 0, 1, 'draft', NULL, NULL, NULL, '2024-12-12 08:26:52', '2024-12-12 08:26:52'),
(3, 'sadf', NULL, 0, 0, 1, 'draft', NULL, NULL, NULL, '2024-12-12 08:27:57', '2024-12-12 08:27:57'),
(4, 'asdf', NULL, 0, 0, 1, 'draft', NULL, NULL, NULL, '2024-12-12 08:31:39', '2024-12-12 08:31:39'),
(5, 'asdf', 78, 0, 1, 1, 'draft', NULL, NULL, NULL, '2024-12-12 08:32:44', '2024-12-12 08:32:44'),
(6, 'asdf', NULL, 0, 0, 1, 'draft', NULL, NULL, NULL, '2024-12-12 08:52:15', '2024-12-12 08:52:15');

-- --------------------------------------------------------

--
-- Table structure for table `poll_choices`
--

DROP TABLE IF EXISTS `poll_choices`;
CREATE TABLE IF NOT EXISTS `poll_choices` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poll_id` int UNSIGNED NOT NULL,
  `votes` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_choices_poll_id_foreign` (`poll_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `poll_choices`
--

INSERT INTO `poll_choices` (`id`, `name`, `poll_id`, `votes`, `created_at`, `updated_at`) VALUES
(1, 'Google Chrome', 1, 0, '2024-12-12 08:26:04', '2024-12-14 02:12:17'),
(2, 'Mozilla Firefox', 1, 0, '2024-12-12 08:26:04', '2024-12-14 02:12:27'),
(3, 'asfdfdsa', 2, 0, '2024-12-12 08:26:52', '2024-12-12 08:26:52'),
(4, 'fasdfasdf', 2, 0, '2024-12-12 08:26:52', '2024-12-12 08:26:52'),
(5, 'safs', 3, 0, '2024-12-12 08:27:57', '2024-12-12 08:27:57'),
(6, 'asdf', 3, 0, '2024-12-12 08:27:57', '2024-12-12 08:27:57'),
(7, 'asfdfsadfasd', 4, 0, '2024-12-12 08:31:39', '2024-12-12 08:31:39'),
(8, 'asfdfsadfasd', 4, 0, '2024-12-12 08:31:39', '2024-12-12 08:31:39'),
(9, 'asfdfsadfasd', 5, 0, '2024-12-12 08:32:44', '2024-12-12 08:32:44'),
(10, 'safs', 5, 0, '2024-12-12 08:32:44', '2024-12-12 08:32:44'),
(11, 'asfdsaf', 6, 0, '2024-12-12 08:52:15', '2024-12-12 08:52:15'),
(12, 'asdfdsf', 6, 0, '2024-12-12 08:52:15', '2024-12-12 08:52:15'),
(15, 'Microsoft Edge', 1, 0, '2024-12-14 02:00:19', '2024-12-14 02:12:35'),
(16, 'Safari', 1, 0, '2024-12-14 02:07:07', '2024-12-14 02:12:44'),
(17, 'Opera', 1, 0, '2024-12-14 02:13:50', '2024-12-14 02:13:50'),
(18, 'Brave', 1, 0, '2024-12-14 02:14:10', '2024-12-14 02:14:10'),
(21, 'Choice 1', 1, 0, '2024-12-14 03:55:03', '2024-12-14 03:55:03');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `quiz_id` int DEFAULT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_1_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_1_image` int DEFAULT NULL,
  `answer_2_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_2_image` int DEFAULT NULL,
  `answer_3_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_3_image` int DEFAULT NULL,
  `answer_4_text` text COLLATE utf8mb4_unicode_ci,
  `answer_4_image` int DEFAULT NULL,
  `answer_5_text` text COLLATE utf8mb4_unicode_ci,
  `answer_5_image` int DEFAULT NULL,
  `correct_answer` enum('1','2','3','4','5') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `quiz_id`, `question`, `answer_1_text`, `answer_1_image`, `answer_2_text`, `answer_2_image`, `answer_3_text`, `answer_3_image`, `answer_4_text`, `answer_4_image`, `answer_5_text`, `answer_5_image`, `correct_answer`, `created_at`, `updated_at`) VALUES
(1, 10, 'questions 1', 'answer 1', NULL, 'answer 2', NULL, 'answer 3', NULL, 'answer 4', NULL, NULL, NULL, '1', NULL, NULL),
(2, 10, 'questions 2', 'answer 1', NULL, 'answer 2', NULL, 'answer 3', NULL, 'answer 4', NULL, NULL, NULL, '3', NULL, NULL),
(3, 10, 'asdad', 'fsfsf', NULL, 'safsf', NULL, 'sfdf', NULL, NULL, NULL, NULL, NULL, '1', '2024-12-11 07:46:52', '2024-12-11 07:46:52'),
(4, 10, 'asdfad', 'fadfds', 81, 'sadsaf', 80, 'asfasf', NULL, NULL, NULL, NULL, NULL, '1', '2024-12-11 07:47:12', '2024-12-11 07:47:12'),
(5, 10, 'asdfsdfsda', 'fasdfasdf', NULL, 'fasdds', NULL, 'asdff', NULL, 'asfdfd', NULL, 'asfad', NULL, '1', '2024-12-11 08:10:03', '2024-12-11 08:10:03'),
(6, 10, 'asfdfasdfa', 'asdfads', NULL, 'fasdfsadf', NULL, 'asdf', NULL, 'asdfdf', NULL, NULL, NULL, '1', '2024-12-11 08:10:24', '2024-12-11 08:10:24');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE IF NOT EXISTS `quizzes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `image` int DEFAULT NULL,
  `category_id` int NOT NULL,
  `type` enum('trivia','personality') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'trivia',
  `no_of_choices` enum('3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '4',
  `result_1` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `result_1_image` text COLLATE utf8mb4_unicode_ci,
  `result_2` text COLLATE utf8mb4_unicode_ci,
  `result_2_image` text COLLATE utf8mb4_unicode_ci,
  `result_3` text COLLATE utf8mb4_unicode_ci,
  `result_3_image` text COLLATE utf8mb4_unicode_ci,
  `result_4` text COLLATE utf8mb4_unicode_ci,
  `result_4_image` text COLLATE utf8mb4_unicode_ci,
  `result_5` text COLLATE utf8mb4_unicode_ci,
  `result_5_image` text COLLATE utf8mb4_unicode_ci,
  `is_featured` tinyint NOT NULL DEFAULT '0',
  `author_id` bigint NOT NULL DEFAULT '1',
  `status` enum('draft','published','scheduled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `meta_title` mediumtext COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `meta_img` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `title`, `slug`, `description`, `image`, `category_id`, `type`, `no_of_choices`, `result_1`, `result_1_image`, `result_2`, `result_2_image`, `result_3`, `result_3_image`, `result_4`, `result_4_image`, `result_5`, `result_5_image`, `is_featured`, `author_id`, `status`, `meta_title`, `meta_description`, `meta_img`, `created_at`, `updated_at`) VALUES
(1, 'Quiz Title', 'quiz-title', '<p><span style=\"font-weight: 600;\">Description</span></p>', NULL, 1, 'trivia', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 01:32:46', '2024-12-10 01:32:46'),
(2, 'Quiz Title 1', 'quiz-title-1', '<p><span style=\"font-weight: 600;\">Description</span></p>', NULL, 1, 'personality', '3', 'Result 1 new', '81', 'Result 2 new', '79', 'Result 3 new', '78', NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 04:56:02', '2024-12-15 08:43:16'),
(3, 'Quiz Title', 'quiz-title-2', '<p><label for=\"title\">Quiz Title</label></p>', NULL, 1, 'trivia', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 04:56:47', '2024-12-10 04:56:47'),
(4, 'Quiz Title', 'quiz-title-3', '<p>Quiz Title</p>', NULL, 1, 'trivia', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 04:59:01', '2024-12-10 04:59:01'),
(5, 'Quiz Title', 'quiz-title-4', '<p>Quiz Title</p>', NULL, 1, 'trivia', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 04:59:34', '2024-12-10 04:59:34'),
(6, 'Quiz Title', 'quiz-title-5', '<p>Quiz Title</p>', NULL, 1, 'trivia', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 05:00:11', '2024-12-10 05:00:11'),
(7, 'Quiz Title', 'quiz-title-6', '<p>Quiz Title</p>', NULL, 1, 'personality', '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 05:05:49', '2024-12-10 05:05:49'),
(9, 'Quiz Title', 'quiz-title-8', '<p><label for=\"title\">Quiz Title</label></p>', 76, 2, 'trivia', '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 'published', NULL, NULL, NULL, '2024-12-10 05:39:26', '2024-12-11 09:38:48'),
(10, 'Quiz Title 10', 'quiz-title-10-11', '<p>Quiz Title 10</p>', 80, 2, 'trivia', '4', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 17, 'scheduled', 'Meta Title', 'Meta Description', NULL, '2024-12-10 06:55:58', '2024-12-11 08:10:10'),
(11, 'Quiz Title', 'quiz-title-10', '<p><label for=\"title\">Quiz Title</label></p>', NULL, 1, 'personality', '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 'published', NULL, NULL, NULL, '2024-12-10 06:58:02', '2024-12-10 06:58:02');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_categories`
--

DROP TABLE IF EXISTS `quiz_categories`;
CREATE TABLE IF NOT EXISTS `quiz_categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` mediumtext COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `meta_img` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_categories`
--

INSERT INTO `quiz_categories` (`id`, `name`, `slug`, `meta_title`, `meta_description`, `meta_img`, `created_at`, `updated_at`) VALUES
(1, 'Movie', 'movie-2', 'Meta Title', 'Meta Description', NULL, NULL, '2024-12-14 05:12:13'),
(2, 'Sports', 'sports', NULL, NULL, NULL, NULL, NULL),
(3, 'Technology', 'technology', 'Meta Title', 'Meta Description', NULL, '2024-12-14 05:13:36', '2024-12-14 05:13:36'),
(4, 'Science', 'science', NULL, NULL, NULL, '2024-12-14 05:13:54', '2024-12-14 05:13:54');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'web', '2024-09-18 08:48:54', '2024-09-18 08:48:54'),
(5, 'Member', 'web', '2024-11-12 05:23:32', '2024-11-12 07:41:02');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE IF NOT EXISTS `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(3, 1),
(3, 5),
(9, 1),
(10, 1),
(11, 1),
(11, 5),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1);

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'system_title', 'Quiz Portal', NULL, '2024-12-09 22:45:39'),
(2, 'contact_email', 'support@quizportal.io', '2024-11-11 00:51:03', '2024-12-09 22:45:39'),
(3, 'contact_phone', '1234567890', '2024-11-11 00:51:03', '2024-11-15 06:46:32'),
(4, 'tab_separator', '|', '2024-11-11 00:51:03', '2024-11-11 01:04:23'),
(5, 'enable_preloader', '1', '2024-11-11 00:59:53', '2024-12-06 04:47:57'),
(6, 'meta_title', 'Qubix Portal Framework', '2024-11-11 01:04:10', '2024-12-06 06:15:06'),
(7, 'meta_description', 'A simple framework for building SAAS using Laravel fast and quick.', '2024-11-11 01:04:10', '2024-12-06 06:19:44'),
(8, 'meta_keywords', 'laravel, framework, qubix portal, saas', '2024-11-11 01:04:10', '2024-12-06 06:20:07'),
(9, 'recaptcha_site_key', 'Your Recaptcha Site Key', '2024-11-11 01:06:42', '2024-12-06 06:45:06'),
(10, 'recaptcha_secret_key', 'Your Recaptcha Secret Key', '2024-11-11 01:06:42', '2024-12-06 06:45:06'),
(11, 'enable_recaptcha', '1', '2024-11-11 01:06:42', '2024-11-11 01:07:10'),
(12, 'header_custom_script', '', '2024-11-11 01:12:09', '2024-12-06 06:37:07'),
(13, 'footer_custom_script', '', '2024-11-11 01:12:09', '2024-12-06 06:29:35'),
(14, 'custom_css', '', '2024-11-11 01:12:09', '2024-12-06 06:34:47'),
(24, 'enable_cookie_consent', '', '2024-11-12 01:51:02', '2024-11-12 01:51:02'),
(16, 'cookie_consent_text', '<p class=\"\">Cookie Consent Text 1</p>', '2024-11-11 01:15:13', '2024-11-12 01:54:15'),
(17, 'maintenance_mode', '1', '2024-11-11 01:15:13', '2024-11-12 01:34:32'),
(18, 'dashboard_light_logo', '71', '2024-11-11 01:18:30', '2024-11-15 12:15:07'),
(19, 'dashboard_dark_logo', '72', '2024-11-11 01:22:39', '2024-11-15 12:15:07'),
(20, 'favicon', '73', '2024-11-11 01:22:39', '2024-11-15 05:06:25'),
(21, 'enable_google_analytics', '', '2024-11-12 01:34:03', '2024-12-06 06:40:11'),
(22, 'google_analytics_tracking_id', '', '2024-11-12 01:34:03', '2024-12-06 06:39:59'),
(25, 'customer_registration', 'email_only', '2024-11-12 02:06:26', '2024-11-12 02:11:17'),
(26, 'registration_verification', 'disabled', '2024-11-12 02:06:26', '2024-11-12 02:12:35'),
(27, 'welcome_email', '1', '2024-11-12 02:06:26', '2024-11-12 02:12:35'),
(28, 'twilio_sid', 'Twilio SID', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(29, 'twilio_auth_token', 'Twilio SID', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(30, 'valid_twilo_number', 'Twilio SID', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(31, 'enable_google_login', '1', '2024-11-12 02:06:26', '2024-11-12 02:06:35'),
(32, 'google_client_id', 'Google Client ID', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(33, 'google_client_secret', 'Google Client Secret', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(34, 'enable_facebook_login', '1', '2024-11-12 02:06:26', '2024-11-12 02:06:35'),
(35, 'faceboo_app_id', 'Facebook App ID', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(36, 'faceboo_app_secret', 'Facebook App Secret', '2024-11-12 02:06:26', '2024-11-12 02:09:12'),
(37, 'mail_type', 'smtp', '2024-11-12 02:20:30', '2024-12-06 08:45:36'),
(38, 'smtp_host', 'sandbox.smtp.mailtrap.io', '2024-11-12 02:20:30', '2024-12-06 08:45:36'),
(39, 'smtp_port', '25', '2024-11-12 02:20:30', '2024-12-06 08:45:36'),
(40, 'mail_username', '35b6a5f28b1bda', '2024-11-12 02:20:30', '2024-11-17 03:04:15'),
(41, 'mail_password', '3bdf99ddb85d7f', '2024-11-12 02:20:30', '2024-11-17 03:04:01'),
(42, 'mail_from_address', 'admin@qubixportal.com', '2024-11-12 02:20:30', '2024-12-06 08:34:16'),
(43, 'mail_from_name', 'Qubix Portal', '2024-11-12 02:20:30', '2024-12-06 08:39:37'),
(44, 'active_storage', 's3', '2024-11-12 02:26:42', '2024-12-06 09:08:54'),
(45, 'aws_access_key', 'AWS Access Key', '2024-11-12 02:26:42', '2024-12-06 09:08:54'),
(46, 'aws_secret_key', 'AWS Secret Access Key', '2024-11-12 02:26:42', '2024-12-06 09:06:12'),
(47, 'aws_s3_bucket_name', 'AWS S3 Bucket Name', '2024-11-12 02:26:42', '2024-12-06 09:06:12'),
(48, 'aws_region', 'AWS Secret Access Key', '2024-11-12 02:26:42', '2024-12-06 09:06:12');

-- --------------------------------------------------------

--
-- Table structure for table `theme_settings`
--

DROP TABLE IF EXISTS `theme_settings`;
CREATE TABLE IF NOT EXISTS `theme_settings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `theme_settings`
--

INSERT INTO `theme_settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'theme_name', 'default-theme', NULL, '2024-11-16 02:16:57'),
(4, 'footer_logo', '71', '2024-11-06 05:42:31', '2024-11-15 11:06:35'),
(5, 'footer_about_us', '<p>Footer about us text</p>', '2024-11-06 05:42:31', '2024-11-15 04:30:19'),
(6, 'footer_newsletter', '<p>Newsletter text</p>', NULL, '2024-11-15 04:30:19'),
(9, 'footer_logo', '', '2024-11-15 04:28:16', '2024-11-15 04:28:16'),
(8, 'copyright_text', '<p>Copyright © 2024 <a href=\"http://qubixportal.test\">QubixPortal</a> - all rights reserved</p>', NULL, '2024-11-15 04:30:55'),
(12, 'site_logo_dark', '72', '2024-11-15 05:10:58', '2024-11-15 05:10:58'),
(13, 'site_logo_light', '71', '2024-11-15 05:11:29', '2024-11-15 05:11:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Istiak Shams', 'istiak2007@gmail.com', NULL, '$2y$10$7WF4ElDZyGyI5idcOxapcul0x7ugAp6W2.vlYuJMh5HXeMUabiKQe', NULL, '2024-09-18 04:44:30', '2024-09-18 04:44:30'),
(17, 'Kamrul Islam', 'kamrul@gmail.com', NULL, '$2y$10$LEAUwAStjxax69mOxwOBNO9M4WM52OXRy20qypG3yWzB2qUz31X6i', NULL, '2024-11-12 07:34:01', '2024-11-17 08:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

DROP TABLE IF EXISTS `votes`;
CREATE TABLE IF NOT EXISTS `votes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `choice_id` int UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `votes_choice_id_foreign` (`choice_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
